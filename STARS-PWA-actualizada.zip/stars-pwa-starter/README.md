# S.T.A.R.S. — base PWA actualizada

Base inicial de la aplicación web progresiva S.T.A.R.S., con diseño monocromático, fondo del árbol, vista de front, historial de cambios, registro de suscripciones push y recepción del evento `CREATE_SWITCH` de PluralKit.

## Estado
- Sistema PluralKit configurado por defecto como `agescw` (ID público confirmado por la persona usuaria).
- Al iniciar, el servidor intenta cargar el front público actual desde PluralKit.
- Los próximos eventos `CREATE_SWITCH` actualizan el front, guardan historial y envían notificaciones a los dispositivos suscritos.
- La serialización JSONB de PostgreSQL está corregida.
- **Todavía no está desplegada ni conectada a Dispatch.** La carga inicial requiere que el servidor tenga conexión a internet y acceso a PostgreSQL.

## Lo que falta para ponerla en funcionamiento
1. Crear una base de datos PostgreSQL persistente.
2. Configurar las variables de entorno indicadas en `.env.example` en el servicio de alojamiento.
3. Generar y guardar claves VAPID en el servidor.
4. Desplegar la app con HTTPS.
5. Crear el webhook Dispatch de PluralKit con la URL `https://TU-DOMINIO/pluralkit` y guardar su signing token como `PK_SIGNING_TOKEN`.
6. Instalar la PWA en los teléfonos y activar las notificaciones.

## Variables necesarias
`DATABASE_URL`, `PK_SIGNING_TOKEN`, `VAPID_PUBLIC_KEY`, `VAPID_PRIVATE_KEY`. `PK_SYSTEM_ID` tiene el valor por defecto `agescw` y se puede sobrescribir en el alojamiento.

Generar claves VAPID (en un entorno Python con `pywebpush` instalado):
```bash
python -c "from py_vapid import Vapid; v=Vapid(); v.generate_keys(); v.save_key('private_key.pem'); print(v.public_key_urlsafe_base64)"
```
La clave privada debe quedar solo como secreto del servidor. No la pegues en el navegador ni la compartas por chat.

## Ejecutar localmente
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export DATABASE_URL='postgresql://...'
export PK_SIGNING_TOKEN='...'
export VAPID_PUBLIC_KEY='...'
export VAPID_PRIVATE_KEY='...'
flask --app app run
```
En Windows PowerShell, usa `$env:NOMBRE="valor"` para definir cada variable de entorno.

## Limitaciones actuales
- El historial empieza a registrar cambios desde que Dispatch queda conectado; la sincronización inicial carga el front actual, pero no importa el historial antiguo.
- Solo procesa `CREATE_SWITCH`. Cambios o eliminaciones de switches requieren ampliar los manejadores de eventos.
- iPhone requiere añadir la PWA a la pantalla de inicio y usar iOS/iPadOS 16.4 o posterior para Web Push. Android necesita un navegador compatible y permiso de notificaciones.
- Un alojamiento gratuito que duerme por inactividad no es adecuado para notificaciones oportunas.
