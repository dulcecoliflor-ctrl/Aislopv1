import os
import json
import hmac
from datetime import datetime, timezone

import psycopg
import requests
from flask import Flask, jsonify, request, send_from_directory
from psycopg.rows import dict_row
from psycopg.types.json import Jsonb
from pywebpush import webpush, WebPushException

app = Flask(__name__, static_folder="static")

DATABASE_URL = os.environ["DATABASE_URL"]
PK_SYSTEM_ID = os.environ.get("PK_SYSTEM_ID", "agescw")
PK_SIGNING_TOKEN = os.environ["PK_SIGNING_TOKEN"]
VAPID_PUBLIC_KEY = os.environ["VAPID_PUBLIC_KEY"]
VAPID_PRIVATE_KEY = os.environ["VAPID_PRIVATE_KEY"]
VAPID_CLAIMS_EMAIL = os.environ.get("VAPID_CLAIMS_EMAIL", "mailto:admin@example.com")
PK_USER_AGENT = os.environ.get("PK_USER_AGENT", "STARS-PWA/0.2 (contact: admin@example.com)")
PK_API = "https://api.pluralkit.me/v2"


def db():
    return psycopg.connect(DATABASE_URL, row_factory=dict_row)


def init_db():
    with db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS stars_state (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                switch_id TEXT,
                switched_at TEXT,
                members JSONB NOT NULL DEFAULT '[]'::jsonb,
                member_names JSONB NOT NULL DEFAULT '[]'::jsonb
            );
            INSERT INTO stars_state (id) VALUES (1) ON CONFLICT (id) DO NOTHING;
            CREATE TABLE IF NOT EXISTS push_subscriptions (
                endpoint TEXT PRIMARY KEY,
                subscription JSONB NOT NULL,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
            );
            CREATE TABLE IF NOT EXISTS switch_history (
                switch_id TEXT PRIMARY KEY,
                switched_at TEXT,
                member_names JSONB NOT NULL DEFAULT '[]'::jsonb,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
            );
        """)


def pk_get(path):
    response = requests.get(
        f"{PK_API}{path}",
        headers={"User-Agent": PK_USER_AGENT},
        timeout=15,
    )
    response.raise_for_status()
    return response.json()


def member_names_from_objects(members):
    names = []
    for member in members or []:
        if isinstance(member, dict):
            names.append(member.get("display_name") or member.get("name") or "Miembro")
        else:
            names.append(str(member))
    return names


def get_member_names(member_ids):
    members = pk_get(f"/systems/{PK_SYSTEM_ID}/members")
    lookup = {
        member.get("id"): member.get("display_name") or member.get("name") or "Miembro"
        for member in members
    }
    names = []
    for item in member_ids or []:
        member_id = item.get("id") if isinstance(item, dict) else item
        names.append(lookup.get(member_id, "Miembro"))
    return names


def sync_current_front():
    """Load the current public fronters once when the server starts."""
    try:
        front = pk_get(f"/systems/{PK_SYSTEM_ID}/fronters")
        members = front.get("members", []) if isinstance(front, dict) else []
        names = member_names_from_objects(members)
        member_ids = [m.get("id") for m in members if isinstance(m, dict) and m.get("id")]
        switched_at = front.get("timestamp") if isinstance(front, dict) else None
        with db() as conn:
            conn.execute(
                """UPDATE stars_state
                   SET switched_at = COALESCE(%s, switched_at), members = %s, member_names = %s
                   WHERE id = 1 AND switch_id IS NULL""",
                (switched_at, Jsonb(member_ids), Jsonb(names)),
            )
        app.logger.info("Initial PluralKit front sync completed")
    except Exception:
        # The app can still start; Dispatch events will update it when configured.
        app.logger.exception("Could not load initial PluralKit fronters")


def send_push(payload):
    with db() as conn:
        rows = conn.execute("SELECT endpoint, subscription FROM push_subscriptions").fetchall()
    stale = []
    for row in rows:
        try:
            webpush(
                subscription_info=row["subscription"],
                data=json.dumps(payload, ensure_ascii=False),
                vapid_private_key=VAPID_PRIVATE_KEY,
                vapid_claims={"sub": VAPID_CLAIMS_EMAIL},
            )
        except WebPushException as exc:
            status = getattr(getattr(exc, "response", None), "status_code", None)
            if status in (404, 410):
                stale.append(row["endpoint"])
            else:
                app.logger.warning("Push delivery failed: %s", exc)
    if stale:
        with db() as conn:
            conn.executemany("DELETE FROM push_subscriptions WHERE endpoint = %s", [(e,) for e in stale])


@app.get("/")
def home():
    return send_from_directory("static", "index.html")


@app.get("/manifest.webmanifest")
def manifest():
    return send_from_directory("static", "manifest.webmanifest")


@app.get("/sw.js")
def service_worker():
    return send_from_directory("static", "sw.js", mimetype="application/javascript")


@app.get("/api/state")
def state():
    with db() as conn:
        row = conn.execute(
            "SELECT switch_id, switched_at, member_names FROM stars_state WHERE id=1"
        ).fetchone()
        history = conn.execute(
            "SELECT switched_at, member_names FROM switch_history ORDER BY created_at DESC LIMIT 20"
        ).fetchall()
    return jsonify({"current": row, "history": history})


@app.get("/api/push-public-key")
def push_public_key():
    return jsonify({"publicKey": VAPID_PUBLIC_KEY})


@app.post("/api/subscribe")
def subscribe():
    subscription = request.get_json(silent=True)
    if not subscription or not subscription.get("endpoint"):
        return jsonify({"error": "Suscripción inválida"}), 400
    with db() as conn:
        conn.execute(
            """INSERT INTO push_subscriptions (endpoint, subscription)
               VALUES (%s, %s)
               ON CONFLICT (endpoint) DO UPDATE SET subscription = EXCLUDED.subscription""",
            (subscription["endpoint"], Jsonb(subscription)),
        )
    return jsonify({"ok": True})


@app.post("/pluralkit")
def pluralkit_dispatch():
    event = request.get_json(silent=True) or {}
    supplied = str(event.get("signing_token", ""))
    if not hmac.compare_digest(supplied, PK_SIGNING_TOKEN):
        return jsonify({"error": "invalid signing token"}), 401
    if event.get("type") == "PING":
        return jsonify({"ok": True}), 200
    if event.get("system_id") != PK_SYSTEM_ID:
        return jsonify({"error": "wrong system"}), 400
    if event.get("type") != "CREATE_SWITCH":
        return jsonify({"ok": True, "ignored": True}), 200

    data = event.get("data") or {}
    switch_id = str(event.get("id") or data.get("id") or "")
    if not switch_id:
        return jsonify({"error": "missing switch id"}), 400

    switched_at = data.get("timestamp") or datetime.now(timezone.utc).isoformat()
    member_ids = data.get("members") or []
    try:
        names = get_member_names(member_ids)
        with db() as conn:
            inserted = conn.execute(
                """INSERT INTO switch_history (switch_id, switched_at, member_names)
                   VALUES (%s, %s, %s)
                   ON CONFLICT (switch_id) DO NOTHING
                   RETURNING switch_id""",
                (switch_id, switched_at, Jsonb(names)),
            ).fetchone()
            conn.execute(
                """UPDATE stars_state
                   SET switch_id=%s, switched_at=%s, members=%s, member_names=%s
                   WHERE id=1""",
                (switch_id, switched_at, Jsonb(member_ids), Jsonb(names)),
            )
        if inserted:
            who = ", ".join(names) if names else "Sin miembros especificados"
            send_push({
                "title": "S.T.A.R.S. · Cambio de front",
                "body": f"Ahora en front: {who}",
                "url": "/",
            })
        return jsonify({"ok": True}), 200
    except Exception:
        app.logger.exception("Dispatch processing failed")
        return jsonify({"error": "processing failed"}), 500


with app.app_context():
    init_db()
    sync_current_front()
