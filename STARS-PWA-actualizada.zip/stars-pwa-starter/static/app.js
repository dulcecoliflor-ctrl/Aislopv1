const $ = (id) => document.getElementById(id);
const fmt = (value) => {
  if (!value) return "Hora no disponible";
  const d = new Date(value);
  return isNaN(d) ? value : d.toLocaleString("es-CL", {dateStyle:"medium", timeStyle:"short"});
};
async function loadState(){
  try{
    const r = await fetch("/api/state");
    if(!r.ok) throw new Error("API");
    const data = await r.json();
    $("connection").textContent = "Conectado";
    const current = data.current;
    const names = current?.member_names || [];
    $("current-members").textContent = names.length ? names.join(", ") : "Sin front registrado";
    $("current-time").textContent = current?.switched_at ? "Último cambio: " + fmt(current.switched_at) : "Aún no hay cambios registrados";
    const history = data.history || [];
    $("history-list").innerHTML = history.length ? history.map(item =>
      `<div class="history-item"><strong>${escapeHtml((item.member_names||[]).join(", ") || "Sin miembros")}</strong><small>${escapeHtml(fmt(item.switched_at))}</small></div>`
    ).join("") : '<p class="muted">Todavía no hay cambios en el historial.</p>';
  }catch(e){ $("connection").textContent = "Sin conexión"; $("current-members").textContent = "No se pudo cargar el estado"; }
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
async function enableNotifications(){
  if(!("serviceWorker" in navigator) || !("PushManager" in window)){alert("Este navegador no admite notificaciones push web.");return;}
  if(!window.isSecureContext){alert("Las notificaciones requieren HTTPS.");return;}
  const permission = await Notification.requestPermission();
  if(permission !== "granted"){alert("No se concedió permiso para notificaciones.");return;}
  const reg = await navigator.serviceWorker.register("/sw.js");
  const keyResponse = await fetch("/api/push-public-key");
  const {publicKey} = await keyResponse.json();
  const subscription = await reg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:urlBase64ToUint8Array(publicKey)});
  const saved = await fetch("/api/subscribe",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(subscription)});
  if(!saved.ok){alert("No se pudo guardar la suscripción. Inténtalo más tarde.");return;}
  $("notify").textContent = "Notificaciones activadas";
}
function urlBase64ToUint8Array(base64String){
  const padding = "=".repeat((4-base64String.length%4)%4);
  const raw = atob((base64String+padding).replace(/-/g,"+").replace(/_/g,"/"));
  return Uint8Array.from([...raw].map(c=>c.charCodeAt(0)));
}
$("notify").addEventListener("click",enableNotifications);
$("refresh").addEventListener("click",loadState);
if("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js").catch(()=>{});
loadState();
